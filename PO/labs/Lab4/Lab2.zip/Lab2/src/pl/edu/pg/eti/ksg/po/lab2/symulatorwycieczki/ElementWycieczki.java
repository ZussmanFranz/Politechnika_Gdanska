package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki;

/**
 *
 * @author TB
 */
public interface ElementWycieczki {
    String getNazwa();
}
