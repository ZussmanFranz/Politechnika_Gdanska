package Abstractions;

public enum ClassType {
    PLANT,
    ANIMAL,
    PLAYER
}
