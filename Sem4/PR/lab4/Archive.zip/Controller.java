public class Controller {
    public volatile boolean stopRequested = false;
}
