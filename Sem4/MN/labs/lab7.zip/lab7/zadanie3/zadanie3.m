close all
format compact

[ft_5, integral_1000, Nt, integration_error] = simpson_rule_accuracy_evaluation();