close all
[A,b,U,T,w,x,r_norm,iteration_count] = solve_Gauss_Seidel();