close all

[coef_double, coef_vpa, y_double, y_vpa, y_mix] = ...
        interpolation_precision_comparison();